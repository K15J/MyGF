package GandF.MyGF.integracion;

public class DAOProductoImp implements DAOProducto{

}
