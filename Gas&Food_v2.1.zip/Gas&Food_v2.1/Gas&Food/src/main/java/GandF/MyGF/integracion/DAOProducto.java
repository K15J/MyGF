package GandF.MyGF.integracion;

public interface DAOProducto {

}
