package GandF.MyGF.business;

public class SADescuento {

}
