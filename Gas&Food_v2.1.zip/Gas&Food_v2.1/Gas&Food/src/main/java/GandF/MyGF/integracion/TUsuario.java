package GandF.MyGF.integracion;

public class TUsuario {

}
