package GandF.MyGF.business;

public class SAUsuario {

}
