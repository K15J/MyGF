package GandF.MyGF.integracion;

public interface DAODescuento {

}
