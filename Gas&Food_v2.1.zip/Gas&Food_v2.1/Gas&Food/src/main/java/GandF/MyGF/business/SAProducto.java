package GandF.MyGF.business;

public class SAProducto {

}
