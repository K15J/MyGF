package GandF.MyGF.integracion;

public class DAOUsuarioImp implements DAOUsuario{

}
